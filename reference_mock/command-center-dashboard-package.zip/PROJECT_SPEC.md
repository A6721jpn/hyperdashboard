# Command Center 仕様書

## 1. 概要

Command Center は、ユーザーが自作する複数のブラウザベースアプリを一括管理するためのローカルダッシュボードである。

対象アプリは次の5種類を初期登録対象とする。

- Image Gen: 画像生成アプリ
- Remote Code: リモートコーディングアプリ
- Brainstorm Chat: 壁打ち用の一対一チャットアプリ
- Slide Builder: スライド作成アプリ
- English Polish: 英語添削アプリ

このダッシュボードは、各アプリの起動、停止、再起動、ブラウザで開く、ログ確認、設定確認をひとつの画面で扱えるようにする。目的は「アプリを作るたびに起動方法やポートを思い出す」状態をなくし、ローカル制作環境の母艦として機能させることである。

## 2. プロダクト方針

Command Center は、ランディングページではなく開発者向けの実用的な管制画面として設計する。

- 情報密度は高めに保つ。
- 状態、操作、ログ、設定の位置を固定し、繰り返し操作しやすくする。
- 派手な装飾より、現在の状態が一目で分かることを優先する。
- 各アプリの詳細画面に移動しなくても、基本的な運用判断ができるようにする。
- 最初はローカルPC上の個人利用を前提とし、共有・チーム運用は将来拡張とする。

## 3. 想定ユーザー

主ユーザーは、Codex などを使ってローカルで小さなWebアプリを複数作っていく個人開発者である。

主な利用シーンは次の通り。

- 複数の自作アプリをまとめて起動する。
- 使いたいアプリをダッシュボードからブラウザで開く。
- ポート番号、起動コマンド、作業ディレクトリを確認する。
- 起動失敗時にログを確認する。
- 作業内容に応じて必要なアプリだけ起動する。
- アプリごとの設定や環境変数を管理する。

## 4. 初期対象アプリ

### 4.1 Image Gen

画像生成、プロンプト実験、生成結果の管理を行うアプリ。

ダッシュボード上で重視する情報:

- 生成キューの状態
- 使用中モデルまたはプリセット
- 出力先フォルダ
- GPUまたはAPI待ち状態
- 直近の生成ログ

想定操作:

- 起動
- 停止
- 再起動
- アプリを開く
- 出力フォルダを開く
- ログ確認

### 4.2 Remote Code

ブラウザ上で使うリモートコーディング環境またはエージェント接続用アプリ。

ダッシュボード上で重視する情報:

- 接続先ワークスペース
- ブランチ
- SSHトンネルまたは接続状態
- 使用ポート
- セッション状態

想定操作:

- 起動
- 停止
- 再接続
- ブラウザIDEを開く
- 作業フォルダを開く
- 接続ログ確認

### 4.3 Brainstorm Chat

一対一で壁打ちするためのプライベートチャットアプリ。

ダッシュボード上で重視する情報:

- 使用モデル
- 会話メモリの有無
- 最新セッション
- 保存済みログまたは transcript
- ローカル限定公開かどうか

想定操作:

- 起動
- 停止
- 新規セッション開始
- 前回セッションを開く
- transcript を開く
- 設定確認

### 4.4 Slide Builder

スライド構成、レイアウト、プレビュー、エクスポートを行うアプリ。

ダッシュボード上で重視する情報:

- 開いているデッキ
- プレビューサーバー状態
- エクスポート状態
- レンダリングエラー
- 出力ファイル

想定操作:

- 起動
- 停止
- プレビューを開く
- 最近のデッキを開く
- エクスポートログ確認
- 出力フォルダを開く

### 4.5 English Polish

英語の添削、言い換え、文体調整を行うアプリ。

ダッシュボード上で重視する情報:

- 入力中の文書
- 添削モード
- トーン設定
- API利用状態
- 最新の添削結果

想定操作:

- 起動
- 停止
- 前回文書を開く
- 添削モードを切り替える
- ログ確認

## 5. 画面仕様

### 5.1 全体レイアウト

モックアップ `dashboard-command-center.html` をベースに、次の4領域で構成する。

```text
┌──────────────────────────────────────────────────────────────┐
│ Sidebar │ Topbar                                             │
│         ├────────────────────────────────────────────────────│
│         │ Metrics                                            │
│         ├──────────────────────────────┬─────────────────────│
│         │ Registered Apps              │ Inspector           │
│         │                              │                     │
│         ├──────────────────────────────┴─────────────────────│
│         │ Live Logs                                          │
└──────────────────────────────────────────────────────────────┘
```

#### Sidebar

主な画面セクションと全体操作を置く。

- Apps
- Sessions
- Logs
- Settings
- Workspace 表示
- Start All
- Stop All

#### Topbar

現在の画面名、検索、アプリ追加ボタンを置く。

- 画面タイトル
- アプリ検索
- コマンド検索
- アプリ追加

#### Metrics

全体状態を短い数値で表示する。

- Running
- Registered
- Memory
- Blocking errors

#### Registered Apps

登録済みアプリの一覧を表示するメイン領域。

表示項目:

- App
- Status
- Port
- Mode
- Controls

#### Inspector

選択中アプリの詳細を表示する右ペイン。

表示項目:

- アプリ名
- ステータス
- URL
- 起動コマンド
- ワークスペースパス
- ヘルスチェック結果
- 操作ボタン
- 運用メモ

#### Live Logs

選択中アプリのログを下部に表示する。

機能:

- stdout/stderr の表示
- ログのクリア
- ログ表示の固定
- 将来的には全アプリ横断ログへ切り替え可能にする

### 5.2 ステータス

アプリの状態は最低限、次のステータスを持つ。

| Status | 意味 | 表示色 |
| --- | --- | --- |
| Running | プロセスが起動しており、URLにアクセス可能 | Green |
| Starting | 起動処理中 | Blue |
| Stopped | 停止中 | Gray |
| Idle | プロセスまたはAPIは利用可能だが、処理対象がない | Amber |
| Error | 起動失敗、ヘルスチェック失敗、異常終了 | Red |

### 5.3 操作ボタン

一覧行と Inspector の両方から操作できるようにする。

必須操作:

- Start
- Stop
- Restart
- Open
- Settings
- Logs

将来操作:

- Open workspace
- Open output folder
- Duplicate app config
- Export logs
- Edit environment variables

### 5.4 検索とコマンド

検索欄は、単なるアプリ検索だけでなくコマンドパレットとしても拡張できる設計にする。

想定入力例:

- `image`
- `start slide`
- `open english`
- `logs remote`
- `restart all`

MVPではアプリ名の絞り込みまで対応し、コマンド実行は将来拡張とする。

## 6. 機能要件

### 6.1 アプリ登録

ユーザーはアプリを登録できる。

登録項目:

- id
- name
- description
- category
- workspacePath
- startCommand
- stopCommand
- url
- port
- healthCheckUrl
- mode
- env
- notes

初期登録として5アプリを用意する。

### 6.2 起動

ユーザーが Start を押すと、対象アプリの `startCommand` を指定の `workspacePath` で実行する。

要件:

- 起動中は `Starting` にする。
- プロセスIDを保存する。
- stdout/stderr をログとして取り込む。
- ヘルスチェックが成功したら `Running` にする。
- 起動失敗時は `Error` にする。

### 6.3 停止

ユーザーが Stop を押すと、対象アプリのプロセスを停止する。

要件:

- 管理対象プロセスのみ停止する。
- 子プロセスも可能な範囲で停止する。
- 停止後は `Stopped` にする。
- 停止ログを残す。

### 6.4 再起動

Restart は Stop と Start を連続して実行する。

要件:

- 停止完了を待ってから再起動する。
- 再起動中は `Starting` にする。
- 失敗した場合は `Error` にし、ログに理由を残す。

### 6.5 ブラウザで開く

Open を押すと、対象アプリの `url` を新しいタブまたは同じブラウザ内で開く。

要件:

- URLが未設定の場合はエラーを表示する。
- 起動していない場合は「起動してから開く」選択肢を出す。
- 既に起動済みの場合は即時に開く。

### 6.6 ログ表示

各アプリの stdout/stderr をリアルタイムに表示する。

要件:

- 選択中アプリのログを下部ドロワーに表示する。
- ログは最新行に追従する。
- Error 状態ではエラー箇所を見つけやすくする。
- MVPではメモリ内保持でよい。
- 将来的にはファイル保存と検索に対応する。

### 6.7 ヘルスチェック

起動後、設定された `healthCheckUrl` にアクセスして正常性を確認する。

要件:

- 2xx または 3xx を成功とする。
- タイムアウト時は再試行する。
- 規定回数失敗したら `Error` にする。
- healthCheckUrl が未設定の場合は、プロセス起動成功を暫定的に `Running` とする。

### 6.8 一括操作

Sidebar から全アプリに対する操作を行う。

MVP対象:

- Start All
- Stop All

将来対象:

- Restart All
- Start Workspace Set
- Stop Idle Apps

## 7. 非機能要件

### 7.1 実行環境

初期想定は Windows ローカル環境とする。

要件:

- PowerShell 経由でコマンドを実行できる。
- Node.js、Python、uv、pnpm などアプリごとの起動コマンド差異を許容する。
- パスに空白が含まれても動作する。
- ポート衝突を検出できる。

### 7.2 セキュリティ

ローカル個人利用を前提にするが、危険なコマンド実行アプリであるため最小限の安全策を入れる。

要件:

- 登録済みコマンドのみ実行する。
- 任意コマンド入力欄はMVPでは作らない。
- ダッシュボードAPIは標準で `127.0.0.1` のみにバインドする。
- 環境変数の値はUI上でマスクできる。
- APIキーなどの秘密情報はログに出さない。

### 7.3 信頼性

要件:

- ダッシュボード再読み込み後もアプリ定義を保持する。
- 管理対象プロセスの状態を再取得できる。
- 起動失敗時にユーザーが原因を追えるログを残す。
- 異常終了したアプリを `Error` に更新する。

### 7.4 パフォーマンス

要件:

- 5から20個程度の登録アプリを快適に扱える。
- ログ表示は大量ログでUIを固めない。
- ヘルスチェックはアプリ数が増えても過剰に頻発させない。

## 8. データ設計

### 8.1 アプリ定義

設定ファイル例:

```json
{
  "apps": [
    {
      "id": "image",
      "name": "Image Gen",
      "description": "Prompt lab and asset output",
      "category": "create",
      "workspacePath": "C:\\apps\\image-gen",
      "startCommand": "npm run dev:image",
      "stopCommand": null,
      "url": "http://127.0.0.1:5173",
      "port": 5173,
      "healthCheckUrl": "http://127.0.0.1:5173",
      "mode": "GPU queue",
      "env": {},
      "notes": "Good default for asset experiments."
    }
  ]
}
```

### 8.2 実行状態

ランタイム状態例:

```json
{
  "image": {
    "status": "running",
    "pid": 12345,
    "startedAt": "2026-05-06T10:21:03+09:00",
    "lastHealthCheckAt": "2026-05-06T10:21:05+09:00",
    "lastError": null,
    "memoryMb": 182,
    "cpuPercent": 3.1
  }
}
```

### 8.3 ログ

ログイベント例:

```json
{
  "appId": "image",
  "timestamp": "2026-05-06T10:21:03+09:00",
  "stream": "stdout",
  "message": "Vite ready at http://127.0.0.1:5173"
}
```

## 9. API設計

ダッシュボードのフロントエンドは、ローカルコントローラーAPIを通じてアプリを管理する。

MVP API:

| Method | Path | 内容 |
| --- | --- | --- |
| GET | `/api/apps` | 登録アプリと現在状態を取得 |
| POST | `/api/apps/:id/start` | アプリを起動 |
| POST | `/api/apps/:id/stop` | アプリを停止 |
| POST | `/api/apps/:id/restart` | アプリを再起動 |
| GET | `/api/apps/:id/logs` | アプリログを取得 |
| GET | `/api/apps/:id/health` | ヘルスチェック結果を取得 |
| POST | `/api/apps/start-all` | 全アプリを起動 |
| POST | `/api/apps/stop-all` | 全アプリを停止 |

将来API:

| Method | Path | 内容 |
| --- | --- | --- |
| POST | `/api/apps` | アプリ登録 |
| PATCH | `/api/apps/:id` | アプリ設定更新 |
| DELETE | `/api/apps/:id` | アプリ登録削除 |
| GET | `/api/sessions` | 実行中セッション一覧 |
| GET | `/api/logs` | 全体ログ検索 |
| POST | `/api/apps/:id/open-folder` | 作業フォルダまたは出力フォルダを開く |

## 10. 推奨アーキテクチャ

### 10.1 構成

```text
Browser UI
  |
  | HTTP / WebSocket
  v
Local Controller Server
  |
  | spawn / kill / health check
  v
Managed App Processes
```

### 10.2 フロントエンド

役割:

- アプリ一覧表示
- 選択中アプリの詳細表示
- 操作ボタン
- ログ表示
- 設定編集

候補技術:

- React
- Vite
- TypeScript
- 軽量な状態管理

### 10.3 ローカルコントローラー

役割:

- 設定ファイル読み込み
- プロセス起動
- プロセス停止
- stdout/stderr 収集
- ヘルスチェック
- WebSocket で状態更新通知

候補技術:

- Node.js
- Fastify または Express
- child_process
- tree-kill 相当のプロセス停止処理

理由:

- Node.js はVite系アプリとの相性がよい。
- フロントエンドと型定義を共有しやすい。
- Windowsでのプロセス起動とログ収集を扱いやすい。

## 11. UIデザイン仕様

### 11.1 基本トーン

開発者用の静かな管制画面。

- 背景: off-white
- パネル: white
- テキスト: charcoal
- アクセント: blue
- Running: green
- Error: red
- Idle: amber
- Stopped: gray

### 11.2 レイアウト寸法

モックアップ基準:

- Sidebar: 256px
- Main padding: 22px
- App table + Inspector の2カラム
- Inspector: 320pxから380px
- パネル角丸: 8px以下
- ボタン角丸: 7px程度

### 11.3 ボタン設計

主要操作は文字付きボタンにする。

- Start All
- Stop All
- Start
- Stop

一覧内の補助操作はアイコンボタン中心にする。

- Start / Stop
- Restart
- Open
- Settings

実装時は、テキスト記号ではなく lucide などのアイコンライブラリを使うことを推奨する。

### 11.4 レスポンシブ

MVPではデスクトップ利用を主対象にする。

最小対応:

- 1080px未満では Sidebar を隠す。
- App table と Inspector を縦積みにする。
- 760px未満ではテーブル行をカード状に縦積みする。

## 12. MVP範囲

最初の実装で作るもの:

- 5アプリの初期登録
- アプリ一覧表示
- 選択中アプリの Inspector 表示
- Start
- Stop
- Restart
- Open
- Start All
- Stop All
- stdout/stderr ログ表示
- ヘルスチェック
- 設定ファイル読み込み

MVPでは作らないもの:

- ユーザー認証
- チーム共有
- クラウド同期
- 任意コマンド実行
- 複雑なスケジューラー
- ログ全文検索
- アプリマーケットプレイス

## 13. 実装フェーズ

### Phase 1: 静的UIから動的UIへ

- 現在のHTMLモックアップをReact/Viteに移植する。
- アプリ一覧をJSONから読み込む。
- 選択、フィルタ、Inspector、ログ表示を実装する。
- ダミー状態でUIの操作感を固める。

### Phase 2: ローカルコントローラー

- Node.js のローカルAPIサーバーを作る。
- アプリ設定ファイルを読み込む。
- Start / Stop / Restart を実プロセスに接続する。
- stdout/stderr をUIに流す。

### Phase 3: 運用品質

- ヘルスチェック
- ポート衝突検出
- 異常終了検知
- ログ保存
- 設定編集UI

### Phase 4: アプリ別拡張

- Image Gen の出力フォルダ表示
- Remote Code のブランチ・接続表示
- Brainstorm Chat のセッション履歴
- Slide Builder の最近のデッキ
- English Polish の前回文書と添削モード

## 14. 受け入れ条件

MVP完了条件:

- ダッシュボードをブラウザで開ける。
- 5つの初期アプリが一覧表示される。
- 各アプリを選択すると Inspector の内容が切り替わる。
- Start / Stop / Restart が対象アプリのプロセスに反映される。
- Open で対象URLを開ける。
- Start All / Stop All が登録アプリに対して実行される。
- 起動ログとエラーログが画面に表示される。
- 起動失敗時に `Error` として表示される。
- 設定ファイルを書き換えることで登録アプリを変更できる。

## 15. 未決定事項

- フロントエンドをReactで作るか、まずは素のHTML/JSを拡張するか。
- ローカルコントローラーをNode.jsで作るか、Pythonで作るか。
- ログをどの期間保存するか。
- 出力フォルダをOSのファイルエクスプローラーで開く機能をMVPに含めるか。
- 各アプリの設定編集をダッシュボード内で行うか、設定ファイル編集を前提にするか。
- 将来的にリモート端末上のアプリも管理対象にするか。

## 16. 現在のモックアップ

現在の参照モックアップ:

- `dashboard-command-center.html`
- `dashboard-command-center.css`
- `dashboard-command-center.js`

このモックアップは、最終実装の画面構成、情報密度、色使い、操作配置の基準として扱う。
