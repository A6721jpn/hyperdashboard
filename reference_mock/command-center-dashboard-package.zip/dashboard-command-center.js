const apps = {
  image: {
    title: "Image Gen",
    status: "Running",
    statusClass: "running",
    url: "http://127.0.0.1:5173",
    command: "npm run dev:image",
    path: "C:\\apps\\image-gen",
    health: "Ready in 1.1s",
    notes:
      "Good default for asset experiments. Keep logs visible while testing model prompts and output folders.",
    logs: [
      "[10:21:02] npm run dev:image",
      "[10:21:03] Vite ready at http://127.0.0.1:5173",
      "[10:21:08] Loaded model presets",
      "[10:22:14] Wrote output to C:\\apps\\image-gen\\outputs",
    ],
  },
  code: {
    title: "Remote Code",
    status: "Running",
    statusClass: "running",
    url: "http://127.0.0.1:8080",
    command: "pnpm dev --host 127.0.0.1",
    path: "C:\\apps\\remote-code",
    health: "Tunnel active",
    notes:
      "Pin this when working in a remote repository. The dashboard should expose branch, session, and port state here.",
    logs: [
      "[10:02:40] Starting remote coding workspace",
      "[10:02:44] Authenticated local session",
      "[10:02:45] Forwarded port 8080",
      "[10:04:11] Extension host ready",
    ],
  },
  chat: {
    title: "Brainstorm Chat",
    status: "Stopped",
    statusClass: "stopped",
    url: "http://127.0.0.1:4420",
    command: "uv run app.py --mode private",
    path: "C:\\apps\\brainstorm-chat",
    health: "Stopped by user",
    notes:
      "This is a private room for thinking through ideas. Its controls should make model, memory, and transcript state obvious.",
    logs: [
      "[09:40:12] Session closed",
      "[09:40:12] Saved transcript draft",
      "[09:40:13] Released port 4420",
    ],
  },
  slide: {
    title: "Slide Builder",
    status: "Running",
    statusClass: "running",
    url: "http://127.0.0.1:3310",
    command: "npm run dev:slides",
    path: "C:\\apps\\slide-builder",
    health: "Preview server ready",
    notes:
      "Best treated as a project app. Surface recent decks, export status, and rendering errors directly in the inspector.",
    logs: [
      "[10:12:01] Loaded deck workspace",
      "[10:12:02] Preview server on port 3310",
      "[10:13:35] Render cache warmed",
      "[10:16:19] Export worker idle",
    ],
  },
  english: {
    title: "English Polish",
    status: "Idle",
    statusClass: "warning",
    url: "http://127.0.0.1:7070",
    command: "python server.py --port 7070",
    path: "C:\\apps\\english-polish",
    health: "API ready, no document loaded",
    notes:
      "Keep input source, rewrite mode, and tone settings visible. The main app can open directly into the last draft.",
    logs: [
      "[10:00:00] English Polish API ready",
      "[10:00:01] Loaded style presets",
      "[10:00:03] Waiting for document input",
    ],
  },
};

const detailTitle = document.querySelector("#detail-title");
const detailStatus = document.querySelector("#detail-status");
const detailUrl = document.querySelector("#detail-url");
const detailCommand = document.querySelector("#detail-command");
const detailPath = document.querySelector("#detail-path");
const detailHealth = document.querySelector("#detail-health");
const detailNotes = document.querySelector("#detail-notes");
const logTitle = document.querySelector("#log-title");
const logOutput = document.querySelector("#log-output");
const runningCount = document.querySelector("#running-count");
const rows = document.querySelectorAll("[data-app]");

let selectedApp = "image";

function renderDetail(appId) {
  const app = apps[appId];
  selectedApp = appId;

  detailTitle.textContent = app.title;
  detailStatus.textContent = app.status;
  detailStatus.className = `status ${app.statusClass}`;
  detailUrl.textContent = app.url;
  detailCommand.textContent = app.command;
  detailPath.textContent = app.path;
  detailHealth.textContent = app.health;
  detailNotes.textContent = app.notes;
  logTitle.textContent = app.title;
  logOutput.textContent = app.logs.join("\n");

  rows.forEach((row) => {
    row.classList.toggle("selected", row.dataset.app === appId);
  });

  renderRows();
}

function addLog(appId, line) {
  apps[appId].logs = [...apps[appId].logs, line].slice(-8);
  if (selectedApp === appId) {
    logOutput.textContent = apps[appId].logs.join("\n");
  }
}

function updateRunningCount() {
  const count = Object.values(apps).filter((app) => app.status === "Running").length;
  runningCount.textContent = String(count);
}

function renderRows() {
  rows.forEach((row) => {
    const app = apps[row.dataset.app];
    const status = row.querySelector(".status");
    const primaryControl = row.querySelector(".controls span:first-child");

    status.textContent = app.status;
    status.className = `status ${app.statusClass}`;
    primaryControl.textContent = app.status === "Running" ? "■" : "▶";
    primaryControl.title = app.status === "Running" ? "Stop" : "Start";
  });
}

function setSelectedStatus(status, statusClass) {
  const app = apps[selectedApp];
  app.status = status;
  app.statusClass = statusClass;
  app.health = status === "Running" ? "Ready just now" : "Stopped by dashboard";
  addLog(selectedApp, `[10:28:00] ${status} via dashboard mock action`);
  renderDetail(selectedApp);
  updateRunningCount();
}

rows.forEach((row) => {
  row.addEventListener("click", () => renderDetail(row.dataset.app));
});

document.querySelector("[data-action='selected-start']").addEventListener("click", () => {
  setSelectedStatus("Running", "running");
});

document.querySelector("[data-action='selected-stop']").addEventListener("click", () => {
  setSelectedStatus("Stopped", "stopped");
});

document.querySelector("[data-action='start-all']").addEventListener("click", () => {
  Object.values(apps).forEach((app) => {
    app.status = "Running";
    app.statusClass = "running";
    app.health = "Ready just now";
  });
  addLog(selectedApp, "[10:28:10] Started all registered apps");
  renderDetail(selectedApp);
  updateRunningCount();
});

document.querySelector("[data-action='stop-all']").addEventListener("click", () => {
  Object.values(apps).forEach((app) => {
    app.status = "Stopped";
    app.statusClass = "stopped";
    app.health = "Stopped by dashboard";
  });
  addLog(selectedApp, "[10:28:20] Stopped all registered apps");
  renderDetail(selectedApp);
  updateRunningCount();
});

renderDetail(selectedApp);
updateRunningCount();
